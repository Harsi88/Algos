To Run the Code:
    In ipython interpreter, import harsimran
    then <list> = harsimran.solve(<numpy_matrix>)
You will have the output in the <list>.
Last element of list contains the score.
